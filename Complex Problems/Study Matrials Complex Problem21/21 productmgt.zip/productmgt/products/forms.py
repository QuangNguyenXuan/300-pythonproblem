from django import forms

class Productsform(forms.Form):
    p1 = forms.IntegerField()
    p2 = forms.IntegerField()
    p3 = forms.IntegerField()
    p4 = forms.IntegerField()
    p5 = forms.IntegerField()
    p6 = forms.IntegerField()
    p7 = forms.IntegerField()
    p8 = forms.IntegerField()
    p9 = forms.IntegerField()
    p10 = forms.IntegerField()