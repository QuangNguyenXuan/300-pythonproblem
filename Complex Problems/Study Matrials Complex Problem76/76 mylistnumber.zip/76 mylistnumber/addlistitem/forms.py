from django import forms

class ListItem(forms.Form):
    l1 = forms.IntegerField()
    l2 = forms.IntegerField()
    l3 = forms.IntegerField()
    l4 = forms.IntegerField()
    l5 = forms.IntegerField()
