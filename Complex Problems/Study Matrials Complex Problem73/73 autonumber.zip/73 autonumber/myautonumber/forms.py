from django import forms

class UserNum(forms.Form):
    n1 = forms.IntegerField()