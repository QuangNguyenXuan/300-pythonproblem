from django.apps import AppConfig


class SetcalculationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'setcalculation'
