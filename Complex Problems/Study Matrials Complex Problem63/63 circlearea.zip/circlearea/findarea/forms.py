from django import forms

class AreaofCircle(forms.Form):
    r = forms.IntegerField()